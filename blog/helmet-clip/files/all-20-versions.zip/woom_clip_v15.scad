// BiKom 20 -> woom helmet rim clip, v15: long arms, interlocking J-teeth, compliant rim wings on the shell radius, tighter curl at the tips.
// Both arms follow the shell (outer on the shell, inner on the foam) up to the vent, then the last
// `over` mm bends on a tighter radius so the tooth turns into the hole from each side.
// Rail plate hangs vertical below the rim from the INNER edge, so the unit sits right under the rim at the ear.
// Frame: X = inward (into helmet), Y = along the rim (front-back), Z = up.

rim_t   = 24;    // rim thickness at the ear (mm)
wall    = 2.5;   // bridge + plate backing thickness
len     = 30;    // clip length along the rim
plate   = 54;    // rail plate height (long axis vertical)
drop    = 0;     // plate top below the rim's bottom edge

hook_o  = 140;   // outside: rim edge -> vent, along the shell (v14: doubled, was 70)
hook_i  = 120;   // inside:  rim edge -> vent, along the foam (v14: doubled, was 60)
shell_r = 130;   // shell curvature radius over the measured length
over    = 5;     // extension past the vent edge, so the tooth lands inside the hole
tip_r   = 65;    // radius of that extension (twice the bend of the main arm)
hook_d  = 13;    // tooth radial length - each crosses past the shell midline so the two overlap
hook_b  = 3;     // J-hook depth (tangential): outer curls down, inner curls up, they latch
hook_off= 3;     // teeth sit this far above/below the vent line so the J's clear each other
wing_l  = 20;    // compliant wings at the base: height along the rim wall
wing_t  = 1.2;   // wing thickness (thin = compliant)
wing_w  = 8;     // wing width, one at each Y end of the clip
wing_in = 3;     // how far the wing tip leans into the rim (flex range)
hook_w  = 6;     // tooth width (< vent opening)
arm_t   = 2;     // arm thickness (light spring)
preload = 1;     // arms sit this much closer to the helmet than the true surface -> minor clamp

module rail() { rotate([0,90,0]) import("files/HelmetClip.stl"); }

z_bot = -drop - plate;
n = 24;
r_out = shell_r - preload;            // outer arm, shell-side radius
r_in  = shell_r - rim_t + preload;    // inner arm, foam-side radius (concentric with the outer)
deg = 180 / PI;

// path: arc 1 (radius r1, length L1) from (x0,0) curling toward +X, then arc 2 (radius r2, length L2)
// continuing tangentially. `t` offsets the path away from the helmet (concentric skins).
function path(r1, L1, r2, L2, x0, t) = let(
    A1 = L1 / r1 * deg, A2 = L2 / r2 * deg,
    c1 = [x0 + r1, 0],
    P  = c1 + r1 * [-cos(A1), sin(A1)],
    c2 = P + r2 * [cos(A1), -sin(A1)]
  ) concat(
    [for (i = [0:n]) let(a = A1 * i / n) c1 + (r1 + t) * [-cos(a), sin(a)]],
    [for (i = [1:n]) let(a = A1 + A2 * i / n) c2 + (r2 + t) * [-cos(a), sin(a)]]);
function tip_dir(r1, L1, r2, L2) = let(a = (L1 / r1 + L2 / r2) * deg) [cos(a), -sin(a)];  // into the helmet wall

module arm(r1, L1, r2, L2, x0) {
  a = path(r1, L1, r2, L2, x0, 0); b = path(r1, L1, r2, L2, x0, -arm_t);   // -t = away from the helmet
  polygon(concat(a, [for (i = [len(b)-1:-1:0]) b[i]]));
}
// J-tooth: radial shaft `hook_d` long from p along dir, then a hook `hook_b` along `curl`; rounded ends
module tooth(p, dir, curl) rotate([90,0,0]) linear_extrude(hook_w, center=true) {
  hull() { translate(p) circle(r = arm_t/2, $fn = 16); translate(p + hook_d*dir) circle(r = arm_t/2, $fn = 16); }
  hull() { translate(p + hook_d*dir) circle(r = arm_t/2, $fn = 16); translate(p + hook_d*dir + hook_b*curl) circle(r = arm_t/2, $fn = 16); }
}

po = path(r_out, hook_o, tip_r, over, 0, 0);                              // outer arm, shell-side skin
pi_ = path(r_in, hook_i, tip_r - rim_t, over, rim_t, 0);                  // inner arm, foam-side skin
// inner arm: its foam-side skin is the one toward -X, i.e. offset +arm_t toward the centre -> build it mirrored
union() {
  rotate([90,0,0]) linear_extrude(len, center=true) union() {
    polygon([[-arm_t, 0], [-arm_t, -wall], [rim_t, -wall], [rim_t, z_bot], [rim_t + wall, z_bot], [rim_t + wall, 0]]);
    arm(r_out, hook_o, tip_r, over, 0);                                    // outer arm, x in [-arm_t, 0] at the bridge
    { a = path(r_in, hook_i, tip_r - rim_t, over, rim_t, 0);
      b = path(r_in, hook_i, tip_r - rim_t, over, rim_t, -arm_t);         // toward +X (away from foam)
      polygon(concat(a, [for (i = [len(b)-1:-1:0]) b[i]])); }
  }
  // teeth: outer sits hook_off above the vent line and curls down, inner sits below and curls up ->
  // pressing the arms together makes the J's pass, then they latch and the arm preload keeps them tensioned
  no = tip_dir(r_out, hook_o, tip_r, over);  uo = [-no[1], no[0]];        // uo = tangent "up" along the outer arm
  ni = tip_dir(r_in, hook_i, tip_r - rim_t, over); ui = [-ni[1], ni[0]];
  tooth(po[len(po)-1] + hook_off*uo,  no, -uo);                            // outer: in, then down
  tooth(pi_[len(pi_)-1] - hook_off*ui, -ni,  ui);                          // inner: out, then up
  // compliant wings: thin leaves at both Y ends, both sides of the rim, leaning in wing_in with a bump
  for (sy = [-1, 1]) translate([0, sy*(len/2 + wing_w/2), 0]) rotate([90,0,0]) linear_extrude(wing_w, center=true) {
    polygon([[-arm_t, 0], [rim_t + arm_t, 0], [rim_t + arm_t, -wall], [-arm_t, -wall]]);       // bridge extension
    polygon([[-wing_t, 0], [0, 0], [wing_in, wing_l], [wing_in - wing_t, wing_l]]);             // outer wing
    translate([wing_in, wing_l - 1]) circle(r = 1, $fn = 16);
    polygon([[rim_t, 0], [rim_t + wing_t, 0], [rim_t - wing_in + wing_t, wing_l], [rim_t - wing_in, wing_l]]); // inner wing
    translate([rim_t - wing_in, wing_l - 1]) circle(r = 1, $fn = 16);
  }
  translate([rim_t - 3 + 0.5, 0, -drop - plate/2]) rail();
}
