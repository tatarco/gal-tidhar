// BiKom 20 -> woom helmet rim clip, v7: long curved outer arm hooking a vent hole.
// Inner spring arm (bump) pinches the rim from inside; the outer arm follows the shell curve up
// to the nearest vent and drops a tooth into it, so the clip can't be pulled back down/out.
// Rail plate hangs vertical below the rim on the outer face, like the hat clip.
// Frame: X = inward (into helmet), Y = along the rim (front-back), Z = up.

rim_t   = 24;    // max rim thickness the clip opens to (mm) - measure the rim, add ~1
squeeze = 4;     // gap narrowing at the inner bump -> the arm flexes up to this much
arm_t   = 1.6;   // inner spring arm thickness
rim_h   = 36;    // inner arm length inside the rim
drop    = 0;     // plate top below the rim's bottom edge
wall    = 2.5;   // rigid wall thickness (bridge + plate backing)
len     = 30;    // clip length along the rim
plate   = 54;    // rail plate height (long axis vertical)
bump    = 1.5;   // inner bump radius

// outer hook arm - measure on the helmet
hook_h  = 70;    // rim edge -> lower edge of the vent hole, along the shell surface
shell_r = 110;   // outer shell curvature radius at the ear side (bigger = flatter)
hook_d  = 4;     // how deep the tooth dips into the vent
hook_w  = 6;     // tooth width (must be < vent opening)
out_t   = 2;     // outer arm thickness (2 = a bit of spring, keeps "minor clamping force")
preload = 1.5;   // arm is drawn this much closer to the shell than shell_r -> light clamping

module rail() { rotate([0,90,0]) import("files/HelmetClip.stl"); }

z_bot = -drop - plate;
x_tip = rim_t - squeeze + bump;
n = 24;
ang = hook_h / (shell_r - preload) * 180 / PI;   // arc angle (deg) for the arm length
function arc(r, s) = [for (i = [0:n]) let(a = ang * i / n) [r - r*cos(a) - s, r*sin(a)]];  // arc from (−s,0) curling to +X
r_arm = shell_r - preload;
outer = arc(r_arm + out_t, wall);      // outer skin of the arm
inner = arc(r_arm, wall - out_t);      // shell-side skin
tip_o = outer[n]; tip_i = inner[n];

union() {
  rotate([90,0,0]) linear_extrude(len, center=true) union() {
    // bridge + plate backing (rigid)
    polygon([[-wall, 0], [-wall, z_bot], [0, z_bot], [0, -wall],
             [rim_t + wall, -wall], [rim_t + wall, 0]]);
    // curved outer arm
    polygon(concat(outer, [for (i = [n:-1:0]) inner[i]]));
    // inner spring arm + bump
    polygon([[rim_t, 0], [rim_t + wall, 0], [x_tip + arm_t, rim_h], [x_tip, rim_h]]);
    translate([x_tip, rim_h - bump]) circle(r = bump, $fn = 24);
  }
  // tooth into the vent: hook_w wide, points at the shell (toward the arc centre)
  rotate([90,0,0]) linear_extrude(hook_w, center=true) hull() {
    translate(tip_i) circle(r = out_t/2, $fn = 16);
    translate(tip_i + hook_d * [cos(ang), -sin(ang)]) circle(r = out_t/2, $fn = 16);
  }
  translate([-wall - 3 + 0.5, 0, -drop - plate/2]) rail();
}
