// BiKom 20 -> woom helmet rim clip, v8: two long curved arms closing on a vent hole.
// Both arms follow the shell curvature (outer on the shell, inner on the foam), run up to the
// nearest vent and drop a tooth into it from each side, so the clip is located by the hole and
// can't be pulled back down. Rail plate hangs vertical below the rim on the outer face.
// Frame: X = inward (into helmet), Y = along the rim (front-back), Z = up.

rim_t   = 24;    // rim thickness at the ear (mm) - measure; the arms are concentric around it
wall    = 2.5;   // bridge + plate backing thickness
len     = 30;    // clip length along the rim
plate   = 54;    // rail plate height (long axis vertical)
drop    = 0;     // plate top below the rim's bottom edge

// arms - measure on the helmet
hook_h  = 70;    // rim edge -> lower edge of the vent hole, along the shell surface
shell_r = 110;   // outer shell curvature radius at the ear side (bigger = flatter)
hook_d  = 4;     // tooth depth into the vent
hook_w  = 6;     // tooth width (< vent opening)
arm_t   = 2;     // arm thickness (2 = light spring, both arms flex)
preload = 1;     // each arm sits this much closer to the helmet than the true surface -> minor clamp

module rail() { rotate([0,90,0]) import("files/HelmetClip.stl"); }

z_bot = -drop - plate;
n = 24;
r_out = shell_r - preload;            // outer arm shell-side radius
r_in  = shell_r - rim_t + preload;    // inner arm foam-side radius (concentric)
ang = hook_h / r_out * 180 / PI;      // arc angle (deg) for the arm length
// arc of radius r whose start is at x = x0, curling toward +X as it rises (centre at (x0 + r, 0))
function arc(r, x0) = [for (i = [0:n]) let(a = ang * i / n) [x0 + r - r*cos(a), r*sin(a)]];
module arm(r, x0, t) polygon(concat(arc(r + t, x0 - t), [for (i = [n:-1:0]) arc(r, x0)[i]]));
module tooth(p, dir) rotate([90,0,0]) linear_extrude(hook_w, center=true) hull() {
  translate(p) circle(r = arm_t/2, $fn = 16);
  translate(p + hook_d * dir) circle(r = arm_t/2, $fn = 16);
}
nrm = [cos(ang), -sin(ang)];          // toward the arc centre = into the helmet wall
tip_out = arc(r_out, 0)[n];           // outer arm, shell-side face, at the vent
tip_in  = arc(r_in, rim_t)[n];        // inner arm, foam-side face (its outer skin faces -X)

union() {
  rotate([90,0,0]) linear_extrude(len, center=true) union() {
    polygon([[-wall, 0], [-wall, z_bot], [0, z_bot], [0, -wall], [rim_t + wall, -wall], [rim_t + wall, 0]]);
    arm(r_out, 0, arm_t);                          // outer arm: x in [-arm_t, 0] at the bridge
    translate([rim_t + arm_t, 0]) arm(r_in - arm_t, 0, arm_t); // inner arm: x in [rim_t, rim_t+arm_t]
  }
  tooth(tip_out, nrm);                             // outer tooth points inward into the vent
  tooth(tip_in, -nrm);                             // inner tooth points outward into the vent
  translate([-wall - 3 + 0.5, 0, -drop - plate/2]) rail();
}
