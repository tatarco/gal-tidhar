// BiKom 20 -> woom helmet rim clip, v5: spring inner arm.
// Outer face hooks over the rim at the ear and hangs below it carrying the stock rail plate (vertical,
// like the hat clip). The inner arm is a thin leaf that tapers inward and ends in a round bump, so it
// flexes over the rim and clamps a range of thicknesses instead of needing an exact rim_t.
// Frame: X = inward (into helmet), Y = along the rim (front-back), Z = up.

rim_t   = 24;    // max rim thickness the clip opens to (mm) - measure the rim, add ~1
squeeze = 4;     // gap narrowing at the inner bump
arm_t   = 1.6;   // spring arm thickness (thinner = softer)
rim_h   = 36;    // inner arm length inside the rim (v6: +50%)
drop    = 0;     // plate top below the rim's bottom edge; negative raises the unit beside the rim
wall    = 2.5;   // rigid wall thickness (outer face + bridge)
len     = 30;    // clip length along the rim
plate   = 54;    // rail plate height (long axis vertical)
bump    = 1.5;   // bump radius at the arm tip

module rail() { rotate([0,90,0]) import("files/HelmetClip.stl"); }  // flat face out (-X)

z_bot = -drop - plate;
x_tip = rim_t - squeeze + bump;      // arm inner face at the top

union() {
  rotate([90,0,0]) linear_extrude(len, center=true) union() {
    // rigid part: outer face + bridge
    polygon([[-wall, rim_h], [-wall, z_bot], [0, z_bot], [0, -wall],
             [rim_t + wall, -wall], [rim_t + wall, 0], [0, 0]]);
    // spring arm: tapers inward from the bridge to the tip
    polygon([[rim_t, 0], [rim_t + wall, 0], [x_tip + arm_t, rim_h], [x_tip, rim_h]]);
    // round bump at the tip = lead-in + grip
    translate([x_tip, rim_h - bump]) circle(r = bump, $fn = 24);
    // matching bump on the outer face, so the rim is pinched from both sides
    translate([0, rim_h - bump]) circle(r = bump, $fn = 24);
  }
  translate([-wall - 3 + 0.5, 0, -drop - plate/2]) rail();
}
