// BiKom 20 -> woom helmet rim clip. Same idea as the Sena hat clip, but the jaw gap is a helmet rim:
// outer face hooks over the rim at the ear, inner arm goes inside like the hat clip's,
// and the stock rail plate sits on the outer face just under the rim so the unit hangs at the ear.
// Frame: X = inward (into helmet), Y = along the rim (front-back), Z = up.

rim_t  = 22;    // helmet rim thickness at the ear, measure it (mm). Set 0.5 under actual for grip.
rim_h  = 18;    // how far the inner arm climbs inside the rim
drop   = 0;     // plate top below the rim's bottom edge; negative raises the unit beside the rim
wall   = 2.5;   // clip wall thickness
len    = 54;    // clip length along the rim (54 = full rail plate)
lip    = 0.8;   // retention lip at the top of the inner arm
plate  = 27;    // stock rail plate height

module rail() { rotate([0,-90,0]) rotate([0,0,90]) import("files/HelmetClip.stl"); }  // tabs face -X

x_in = rim_t + wall;
z_bot = -drop - plate;              // bottom of the outer face

union() {
  // profile: outer face (hangs below the rim) + bridge under the rim + inner arm
  rotate([90,0,0]) linear_extrude(len, center=true) polygon([
    [-wall, rim_h], [-wall, z_bot], [0, z_bot], [0, -wall],
    [x_in, -wall], [x_in, rim_h], [rim_t - lip, rim_h], [rim_t, rim_h - 2*lip], [rim_t, 0],
    [0, 0]
  ]);
  // rail plate on the outer face, 0.5mm sunk in, long axis along the rim
  translate([-wall + 0.5, 0, -drop - plate/2]) rail();
}
