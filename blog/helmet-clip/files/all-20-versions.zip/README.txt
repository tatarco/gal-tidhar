Bikom 20 Helmet Clip by HenryHase on Thingiverse: https://www.thingiverse.com/thing:7354158

Summary:
This is a replacement helmet band clip for the Sena Bikom 20